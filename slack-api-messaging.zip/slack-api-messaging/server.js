const express = require('express');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');
const axios = require('axios');
const path = require('path');

dotenv.config();
const app = express();
const PORT = 3000;


app.use(bodyParser.json());
app.use(express.static('public'));

const SLACK_BOT_TOKEN = process.env.SLACK_BOT_TOKEN;
const SLACK_CHANNEL = 'C093KR1T28J';
console.log("Using Slack token:", SLACK_BOT_TOKEN);



app.post('/send-message', async (req, res) => {
  const { message } = req.body;

  try {
    const response = await axios.post('https://slack.com/api/chat.postMessage', {
      channel: SLACK_CHANNEL,
      text: message
    }, {
      headers: {
        Authorization: `Bearer ${SLACK_BOT_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.data.ok) {
      res.json({ success: true, ts: response.data.ts });
    } else {
      res.status(500).json({ success: false, error: response.data.error });
    }

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
app.post('/schedule-message', async (req, res) => {
  const { message, postAt } = req.body;

  console.log("👉 Scheduling message:", message);
  console.log("🕒 Scheduled time (Unix):", postAt);

  try {
    const response = await axios.post('https://slack.com/api/chat.scheduleMessage', {
      channel: SLACK_CHANNEL,
      text: message,
      post_at: postAt
    }, {
      headers: {
        Authorization: `Bearer ${SLACK_BOT_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    console.log("🔁 Slack API response:", response.data);

    if (response.data.ok) {
      res.json({ success: true, scheduled_message_id: response.data.scheduled_message_id });
    } else {
      res.status(500).json({ success: false, error: response.data.error });
    }

  } catch (error) {
    console.log("❌ Error:", error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});
// 3️⃣ Retrieve Messages Endpoint
app.get('/retrieve-messages', async (req, res) => {
  try {
    const response = await axios.get('https://slack.com/api/conversations.history', {
      params: {
        channel: SLACK_CHANNEL,
        limit: 10  // Fetch last 10 messages
      },
      headers: {
        Authorization: `Bearer ${SLACK_BOT_TOKEN}`
      }
    });

    console.log("🔁 Retrieved messages:", response.data);

    if (response.data.ok) {
      res.json({ success: true, messages: response.data.messages });
    } else {
      res.status(500).json({ success: false, error: response.data.error });
    }

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
// 4️⃣ Edit Message Endpoint
app.post('/edit-message', async (req, res) => {
  const { ts, newText } = req.body;

  try {
    const response = await axios.post('https://slack.com/api/chat.update', {
      channel: SLACK_CHANNEL,
      ts: ts,
      text: newText
    }, {
      headers: {
        Authorization: `Bearer ${SLACK_BOT_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    console.log("✏️ Edit Response:", response.data);

    if (response.data.ok) {
      res.json({ success: true });
    } else {
      res.status(500).json({ success: false, error: response.data.error });
    }

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
// 5️⃣ Delete Message Endpoint
app.post('/delete-message', async (req, res) => {
  const { ts } = req.body;

  try {
    const response = await axios.post('https://slack.com/api/chat.delete', {
      channel: SLACK_CHANNEL,
      ts: ts
    }, {
      headers: {
        Authorization: `Bearer ${SLACK_BOT_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    console.log("❌ Delete Response:", response.data);

    if (response.data.ok) {
      res.json({ success: true });
    } else {
      res.status(500).json({ success: false, error: response.data.error });
    }

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});




app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
